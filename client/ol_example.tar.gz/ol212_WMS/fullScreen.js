var map = null;

function init(){

    // map options
    var options = {
              projection: new OpenLayers.Projection("EPSG:900913"),
              displayProjection: new OpenLayers.Projection("EPSG:4326"),
              units: "m",
              numZoomLevels: 20,
              maxResolution: 156543.0339,
              maxExtent: new OpenLayers.Bounds(-20037508, -20037508,
                                  20037508, 20037508.34)
    };
    map = new OpenLayers.Map( 'map', options );

    //  layers
    var gmap = new OpenLayers.Layer.Google(
          "Google Streets", // the default
          {'sphericalMercator': true, numZoomLevels: 20}
    );
    var osm = new OpenLayers.Layer.OSM( 
          "Open Street Maps"
    );
    

    /*
    {
    layers: [
    new OpenLayers.Layer.OSM(
            "Open Street Maps"
    ),
	new OpenLayers.Layer.Google(
            "Google Streets", // the default
            {numZoomLevels: 20}
	),
	new OpenLayers.Layer.Google(
            "Google Physical",
            {type: google.maps.MapTypeId.TERRAIN}
	),
	new OpenLayers.Layer.Google(
            "Google Hybrid",
            {type: google.maps.MapTypeId.HYBRID}
	),
	new OpenLayers.Layer.Google(
            "Google Satellite",
            {type: google.maps.MapTypeId.SATELLITE}
	)
    ],
    controls: [
        new OpenLayers.Control.Navigation(),
        new OpenLayers.Control.PanZoom(),
        new OpenLayers.Control.Attribution()
    ],
    center: [-179.0, 47.0],
    zoom: 3
    }
    */

    var wmslayer1 = new OpenLayers.Layer.WMS( 
            "ice (no gutter)", 
            "http://bpgomex.erma.unh.edu/wms/National_Ice_Center?",
            { 
                layers: "Daily_Ice_Extent_latest", 
                transparent: 'true',
                format: 'image/png', 
            },
            {
                tileSize: new OpenLayers.Size(256,256),
                ratio: 1, 
                wrapDateLine: true
            }
    );

    var wmslayer2 = new OpenLayers.Layer.WMS( 
            "ice (10px gutter)", 
            "http://bpgomex.erma.unh.edu/wms/National_Ice_Center?",
            { 
                layers: "Daily_Ice_Extent_latest", 
                transparent: 'true',
                format: 'image/png', 
            },
            {
                tileSize: new OpenLayers.Size(256,256),
                ratio: 1, 
                wrapDateLine: true, 
                visibility: false,
                gutter: 10
            }
    );

    map.addLayers( [ osm, gmap, wmslayer1, wmslayer2 ] );

    map.addControl(new OpenLayers.Control.LayerSwitcher());

    // Coordinate display at bottom of map
    map.addControl(new OpenLayers.Control.MousePosition());
    var point = new OpenLayers.LonLat(-179.876 , 40.86052); 
    // Need to convert zoom point to mercator too
    point.transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject());
    map.setCenter(point, 3); 

}
